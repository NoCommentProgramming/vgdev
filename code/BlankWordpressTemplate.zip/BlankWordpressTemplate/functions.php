<?php

	// add theme support
	if (function_exists('add_theme_support')) {
	    // Add Menu Support
	    add_theme_support('menus');
	}

	// main navigation
	function navigation($input) {
		if ($input == 'main' ||
			$input == 'secondary' ||
			$input == 'mobile' ||
			$input == 'footer') {

			wp_nav_menu(
			array(
				'theme_location'  => $input + '-menu',
				'menu'            => '',
				'container'       => '',
				'container_class' => '',
				'container_id'    => '',
				'menu_class'      => $input + '_navigation',
				'menu_id'         => '',
				'echo'            => true,
				'fallback_cb'     => 'wp_page_menu',
				'before'          => '',
				'after'           => '',
				'link_before'     => '',
				'link_after'      => '',
				'items_wrap'      => '<ul>%3$s</ul>',
				'depth'           => 0,
				'walker'          => ''
				)
			);
		}
	}

	// register custom menus
	if (function_exists('register_nav_menus')) {
		register_nav_menus(
			array(
			  'main_menu' => __( 'Main Menu', 'cake' ), // main navigation
			  'secondary_menu' => __( 'Secondary Menu', 'cake' ), // secondary navigation
			  'mobile_menu' => __( 'Mobile Menu', 'cake' ), // mobile navigation
			  'footer_menu' => __( 'Footer Menu', 'cake' ) // footer navigation
			)
		);
	}

?>