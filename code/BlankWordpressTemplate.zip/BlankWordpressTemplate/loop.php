				<?php if(have_posts()) :?>
                	<?php the_title(); ?>
                	<?php the_content(); ?>
				<?php endif; ?>