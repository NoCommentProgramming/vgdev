<?php get_header(); ?>

		<!-- container -->
		<div class="container">

			<!-- wrapper -->
			<div class="wrapper">

				<h1><?php the_title(); ?></h1>

				<?php if (have_posts()): ?>
				<?php while (have_posts()) : the_post(); ?>

					<?php the_content(); ?>

				<?php endwhile; ?>
				<?php endif; ?>

			</div>
			<!-- /wrapper -->

		</div>
		<!-- / container -->

<?php get_footer(); ?>