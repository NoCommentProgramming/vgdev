<?php get_header(); ?>

		<!-- container -->
		<div class="container">

			<!-- wrapper -->
			<div class="wrapper">

				<?php include('loop.php'); ?>
				
			</div>
			<!-- /wrapper -->

		</div>
		<!-- / container -->

<?php get_footer(); ?>