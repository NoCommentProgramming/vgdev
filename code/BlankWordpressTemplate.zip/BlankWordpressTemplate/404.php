<?php get_header(); ?>

		<!-- container -->
		<div class="container">

			<!-- wrapper -->
			<div class="wrapper">

				<p>I am sorry, but this page does not exist...</p>

			</div>
			<!-- /wrapper -->

		</div>
		<!-- / container -->

<?php get_footer(); ?>