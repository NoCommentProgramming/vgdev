
		<!-- footer -->
		<div class="container" id="footer">

			<!-- wrapper -->
			<div class="wrapper">

				<?php navigation('main'); ?>

			</div>
			<!-- /wrapper -->

		</div>
		<!-- / footer -->

		<!-- load css -->

		<!-- load javascript -->
		<script src="<?php echo get_template_directory_uri(); ?>/js/scripts.js"></script>

	</body>
</html>