<?php get_header(); ?>

		<!-- container -->
		<div class="container">

			<!-- wrapper -->
			<div class="wrapper">

				<?php the_title(); ?>
				<?php the_content(); ?>

			</div>
			<!-- /wrapper -->

		</div>
		<!-- / container -->

<?php get_footer(); ?>